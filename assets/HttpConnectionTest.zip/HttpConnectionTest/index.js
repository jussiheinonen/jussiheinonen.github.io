var net = require('net');

module.exports = async function (context, req) {
    context.log('JavaScript HTTP trigger function processed a request.');

    const host = (req.query.host || (req.body && req.body.host));
    const port = (req.query.port || (req.body && req.body.port));

    if (host && port) {
        logmessage = 'Testing connectivity to host ' + host + ' on port ' + port;
        context.log(logmessage);
        var responseMessage = logmessage;

    }
    else {
        logmessage = 'Missing URL parameters for host and/or port. Unable to test connection.\n\nExample parameters: /api/HttpConnectionTest?host=192.168.0.1&port=443';
        context.log(logmessage);
        var responseMessage = logmessage;
    }

    //const responseMessage = name
    //    ? "Hello, " + name + ". This HTTP triggered function executed successfully."
    //   : "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.";

    context.res = {
        // status: 200, /* Defaults to 200 */
        body: responseMessage
    };
}
