import logging
from pprint import pprint

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    name = req.params.get('name')
    
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name == "jussi" or name == "Jussi":
        msg = "Hello, " + name + ". How's your demo working?"
        logging.info(msg)
        return func.HttpResponse(msg)
    elif name:
        msg = "Hello, " + name + ". It's Tuesday. I hope you have a great day!"
        logging.info(msg)
        return func.HttpResponse(msg)
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
